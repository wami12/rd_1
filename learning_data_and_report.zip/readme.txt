09.01.2020 A1
15.01.2020 A2
21.01.2020 A3 -STORM EVENT
27.01.2020 A4
14.02.2020 A5
'RFC','DTC','MLPC','KN'

### A1: ### learning_dataset_1_final.parquet (mask 1,2,3)
file.amp_vv = 'VV/01_Amplitude/A1_VV.bin.grd'
file.amp_vh = 'VH/01_Amplitude/A1_VH.bin.grd'
file.rgb = 'dane_z_wms/20200116-Delta-Sentinel2-rgb_transformed.tif' #DO NOT USE for this day 
file.mask_flooded = 'mask_flooded_2.shp' # 'mask_flooded.shp'
file.mask_dry = 'mask_dry_2.shp' # 'mask_dry.shp'

### A2: ### learning_dataset_2_final.parquet (mask 1,2,3)
file.amp_vv = 'VV/01_Amplitude/A2_VV.bin.grd'
file.amp_vh = 'VH/01_Amplitude/A2_VH.bin.grd'
file.coh_vv = 'VV/02_Coherence/coh_int00002_20200109_20200115_-82_6_ml210w420.oct.grd'
file.rgb = 'dane_z_wms/20200116-Delta-Sentinel2-rgb_transformed.tif'
file.mask_flooded = 'mask_flooded_2.shp' # 'mask_flooded.shp'
file.mask_dry = 'mask_dry_2.shp' # 'mask_dry.shp'

### A3: ### learning_dataset_3_final.parquet (mask 2,3), dla mask 1 nie używać atrybutów RGB do predykcji 
file.amp_vv = 'VV/01_Amplitude/A3_VV.bin.grd'
file.amp_vh = 'VH/01_Amplitude/A3_VH.bin.grd'
file.coh_vv = 'VV/02_Coherence/coh_int00006_20200115_20200121_41_6_ml210w420.oct.grd'
file.coh_vh = 'VH/02_Coherence/coh_int00006_20200115_20200121_41_6_ml210w420.oct.grd'
file.rgb = 'dane_z_wms/20200123-Delta-Sentinel2-rgb_transformed.tif'
file.mask_flooded = 'mask_flooded_2.shp' #Tylko te, zmniejszonec (i zbilansowane) maski
file.mask_dry = 'mask_dry_2.shp' #Tylko te zmniejszone maski

### A4: ### learning_dataset_4_final.parquet (mask 1,2,3)
file.amp_vv = 'VV/01_Amplitude/A4_VV.bin.grd'
file.amp_vh = 'VH/01_Amplitude/A4_VH.bin.grd'
file.coh_vv = 'VV/02_Coherence/coh_int00007_20200121_20200127_-55_6_ml210w420.oct.grd'
file.coh_vh = 'VH/02_Coherence/coh_int00007_20200121_20200127_-55_6_ml210w420.oct.grd'
file.rgb = 'dane_z_wms/20200126-Delta-Sentinel2-rgb_transformed.tif'
file.mask_flooded = 'mask_flooded_2.shp' # 'mask_flooded.shp'
file.mask_dry = 'mask_dry_2.shp' # 'mask_dry.shp'


### A5: ### learning_dataset_5_final.parquet (mask 3), dla mask1 nie używać atrybutów RGB do predykcji
file.amp_vv = 'VV/01_Amplitude/A5_VV.bin.grd'
file.amp_vh = 'VH/01_Amplitude/A5_VH.bin.grd'
file.coh_vv = 'VV/02_Coherence/coh_int00011_20200208_20200214_-62_6_ml210w420.oct.grd'
file.coh_vh = 'VH/02_Coherence/coh_int00011_20200208_20200214_-62_6_ml210w420.oct.grd'
file.rgb = 'dane_z_wms/202001-Costa10cm-Delta15cm-rgb_transformed.tif'
file.mask_flooded = 'mask_flooded_3.shp'
file.mask_dry = 'mask_dry_3.shp'


Datasets created for different input files.
1. learning_dataset_1.parquet - for A1 amplitudes:
	addAttribute('AMP_A_VV','VV/01_Amplitude/A1_VV.bin.grd','learning_data.parquet')
	addAttribute('AMP_A_VH','VH/01_Amplitude/A1_VH.bin.grd','learning_data.parquet')
	addAttribute('COH_INT00002_VV','VV/02_Coherence/coh_int00002_20200109_20200115_-82_6_ml210w420.oct.grd','learning_data.parquet')
	addAttribute('COH_INT00006_VH','VH/02_Coherence/coh_int00006_20200115_20200121_41_6_ml210w420.oct.grd','learning_data.parquet')
	addAttribute('COH_INT00006_VV','VV/02_Coherence/coh_int00006_20200115_20200121_41_6_ml210w420.oct.grd','learning_data.parquet')

2. learning_dataset_3.parquet - for A3 amplitudes:
	addAttribute('AMP_A_VV','VV/01_Amplitude/A3_VV.bin.grd','learning_data_3.parquet')
	addAttribute('AMP_A_VH','VH/01_Amplitude/A3_VH.bin.grd','learning_data_3.parquet')
	addAttribute('COH_INT00002_VV','VV/02_Coherence/coh_int00002_20200109_20200115_-82_6_ml210w420.oct.grd','learning_data_3.parquet')
	addAttribute('COH_INT00006_VH','VH/02_Coherence/coh_int00006_20200115_20200121_41_6_ml210w420.oct.grd','learning_data_3.parquet')
	addAttribute('COH_INT00006_VV','VV/02_Coherence/coh_int00006_20200115_20200121_41_6_ml210w420.oct.grd','learning_data_3.parquet')
	
3. learning_dataset_3_noise_removed.parquet - for A3 amplitudes VV,VH, with removed noise by median filtering with size: 1,2,3:
	addAttribute('AMP_A_VV_SIZE1',noise_remove('VV/01_Amplitude/A3_VV.bin.grd',1),'learning_data_3_noise_removed.parquet')
	addAttribute('AMP_A_VV_SIZE2',noise_remove('VV/01_Amplitude/A3_VV.bin.grd',2),'learning_data_3_noise_removed.parquet')
	addAttribute('AMP_A_VV_SIZE3',noise_remove('VV/01_Amplitude/A3_VV.bin.grd',3),'learning_data_3_noise_removed.parquet')
	addAttribute('AMP_A_VH_SIZE1',noise_remove('VV/01_Amplitude/A3_VV.bin.grd',1),'learning_data_3_noise_removed.parquet')
	addAttribute('AMP_A_VH_SIZE2',noise_remove('VV/01_Amplitude/A3_VV.bin.grd',2),'learning_data_3_noise_removed.parquet')
	addAttribute('AMP_A_VH_SIZE3',noise_remove('VV/01_Amplitude/A3_VV.bin.grd',3),'learning_data_3_noise_removed.parquet')

4. learning_data_3_mask_noise_removed.parquet - data gathered by masking using SHP files - for A3 amplitudes, VV,VH, with removed noise by median filtering with size: 1,2,3

5. learning_data_1_mask_noise_removed.parquet - data gathered by masking using SHP files - for A1 amplitudes, VV,VH, with removed noise by median filtering with size: 1,2,3

6. learning_data_2_mask_noise_removed.parquet - data gathered by masking using SHP files - for A2 amplitudes, VV,VH, with removed noise by median filtering with size: 1,2,3

7. learning_data_2_mask_2_noise_removed.parquet - data gathered by masking using SHP files - for A2 amplitudes, VV,VH, with removed noise by median filtering with size: 1,2,3, masks changed, defined differently than in steps 1-6

8. learning_data_rgb_sentinel_20200116_mask_2_small.parquet - data gathered by masking using SHP files - for RGB bands, 1,2,3,4, used small masks (mask_dry_small, mask_flooded_small)

9. learning_data_2_rgb_sentinel_20200116.parquet - data gathered by points (original) for RGB 4 bands values, A2 amplitudes VV, VH and coherences int00002 VV and noise remove 1,2,3 - from files:
	'dane_z_wms/20200116-Delta-Sentinel2-rgb_transformed.tif'
	'VV/01_Amplitude/A2_VV.bin.grd'
	'VH/01_Amplitude/A2_VH.bin.grd'
	'VV/02_Coherence/coh_int00002_20200109_20200115_-82_6_ml210w420.oct.grd'

10. learning_data_2_rgb_sentinel_20200116_mask.parquet - data gathered by SHP masks for RGB 3 bands values, A2 amplitudes VV, VH and coherences int00002 VV and noise remove 2. All files resampled to resolution of: coh_int00002_20200109_20200115_-82_6_ml210w420.oct.grd' (which is lower than sentinel image). Files used:
	'dane_z_wms/20200116-Delta-Sentinel2-rgb_transformed.tif'
	'VV/01_Amplitude/A2_VV.bin.grd'
	'VH/01_Amplitude/A2_VH.bin.grd'
	'VV/02_Coherence/coh_int00002_20200109_20200115_-82_6_ml210w420.oct.grd'

11. learning_data_2_rgb_sentinel_20200116_mask_hi_res.parquet - data gathered in HIGH RESOLUTION (based on Sentinel 2 image) by SHP masks for RGB 3 bands values, A2 amplitudes VV, VH and coherences int00002 VV and noise remove 2. All files resampled to resolution of: 20200116-Delta-Sentinel2-rgb_transformed.tif (which is higher than sentinel SAR images). Files used:
	'dane_z_wms/20200116-Delta-Sentinel2-rgb_transformed.tif'
	'VV/01_Amplitude/A2_VV.bin.grd'
	'VH/01_Amplitude/A2_VH.bin.grd'
	'VV/02_Coherence/coh_int00002_20200109_20200115_-82_6_ml210w420.oct.grd'

	
